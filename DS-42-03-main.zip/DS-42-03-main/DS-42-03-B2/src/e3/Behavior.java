package e3;

public interface Behavior {

    GunslingerAction action(Gunslinger g);

}


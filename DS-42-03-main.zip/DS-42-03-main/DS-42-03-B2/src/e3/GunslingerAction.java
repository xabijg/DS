package e3;

public enum GunslingerAction {

        SHOOT,
        RELOAD,
        PROTECT,
        MACHINE_GUN


}
